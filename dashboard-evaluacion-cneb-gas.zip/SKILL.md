---
name: dashboard-evaluacion-cneb-gas
description: Genera Code.gs e Index.html en Google Apps Script para analizar datos de evaluacion formativa segun CNEB desde Google Sheets. Usalo cuando el usuario pida crear o actualizar un dashboard escolar, analizar calificaciones cualitativas (AD, A, B, C), evaluar riesgo pedagogico o procesar la hoja Datos_40_estudiantes.
---
# Dashboard de Evaluación Formativa CNEB (Google Apps Script)

Genera el código completo de `Code.gs` (obligatorio) e `Index.html` (obligatorio) para analizar el archivo **Datos_40_estudiantes** en Google Sheets. La hoja **Guia** del archivo es la especificación mandatoria: si algo la contradice, se sigue la Guia y se notifica al usuario.

## 1. Marco Pedagógico (CNEB, RVM N.° 094-2020-MINEDU)

Escala ordinal estricta. **Nunca se promedian letras ni se convierten a escala vigesimal**.

| Nivel | Orden | Descripción (CNEB) | Acción en Dashboard |
|---|---|---|---|
| AD - Logro destacado | 4 | Evidencia nivel superior al esperado. | Retos de extensión, tutoría entre pares. |
| A - Logro esperado | 3 | Nivel esperado con manejo satisfactorio. | Consolidar y diversificar situaciones. |
| B - En proceso | 2 | Próximo al esperado; requiere acompañamiento. | Retroalimentación descriptiva y práctica guiada. |
| C - En inicio | 1 | Progreso mínimo; dificultades frecuentes. | Intervención focalizada y seguimiento continuo. |

Reglas estadísticas:
- El orden (1-4) solo se usa para **ordenar y calcular medianas/modas ordinales**.
- Estadísticos permitidos: conteos, proporciones/porcentajes por nivel, moda y mediana (expresadas en letra), % de logro ordinal: `(AD + A) / disponibles`.
- **Prohibido**: media aritmética de letras, desviaciones estándar, boxplots numéricos de notas.
- **Regla de Mediana Ordinal Par**: Al calcular la mediana sobre un número par de notas ordenadas, si el punto medio cae entre dos niveles distintos (ej. posición central entre B [2] y A [3] = 2.5), tomar el valor inferior (`Math.floor`) para reportar la letra base (en este caso B). Esto previene errores `undefined` y garantiza un enfoque preventivo de alerta formativa temprana.
- En este conjunto de datos "Conceptos, Procedimientos, Aplicacion" son **criterios** de evaluación por curso, no competencias. Rotularlos siempre como **"Criterio"**.

## 2. Esquema de Entrada (Hojas Fuente de Solo Lectura)

| Hoja | Columnas | Filas base (4 periodos) |
|---|---|---|
| Alumnos | Alumno_ID, Seccion (A/B) | 40 |
| Evaluaciones | Alumno_ID, Periodo, Curso, Competencia, Nota (AD/A/B/C o vacío), Disponible | 960 (24 vacías por diseño en 4P; escala con periodos adicionales) |
| Asistencia | Alumno_ID, Periodo, Programadas, Asistidas | 160 (escala con periodos adicionales) |
| Actividades | Alumno_ID, Periodo, Curso, Asignadas, Entregadas | 320 (escala con periodos adicionales) |
| Resumen, Guia | Informativas | Solo lectura |

- **Detección Dinámica y Ordenamiento Natural de Periodos**: Extraer los periodos presentes dinámicamente de los datos y ordenarlos numéricamente mediante extracción de dígitos (`parseInt(p.replace(/\D/g, ''), 10)`), para evitar que P10 se ubique antes que P2 o que nuevos periodos como P5 queden desordenados o ignorados. El último periodo tras el ordenamiento es el periodo activo a evaluar.
- Leer encabezados por **nombre**, no por índice de columna.
- Normalizar Nota con `String(v).trim().toUpperCase()`. Vacío = **sin calificación** (no es C ni cero; se excluye del denominador y se cuenta aparte).
- La asistencia es **global por alumno y periodo**: no se suma ni se duplica al filtrar por curso.

## 3. Arquitectura en Google Apps Script (`Code.gs`)

La respuesta generada por el agente debe devolver el código ejecutable de `Code.gs`. La constante `ID_HOJA` es obligatoria en la cabecera, junto con soporte para ID o URL completa:

```javascript
// REQUERIDO: Reemplazar con el ID o URL completa del Google Sheet 'Datos_40_estudiantes'
const ID_HOJA = 'PEGAR_ID_O_URL_DEL_GOOGLE_SHEET';
const NIVELES = { C: 1, B: 2, A: 3, AD: 4 };
const LETRA = { 1: 'C', 2: 'B', 3: 'A', 4: 'AD' };
const UMBRALES = {
  propC_alto: 0.50,
  propC_altoCombinado: 0.34,
  asistencia_alta: 0.80,
  asistencia_media: 0.90,
  entregas_alta: 0.60,
  entregas_media: 0.80,
  propB_medio: 0.50,
  minDisponibles: 0.50
};
const HOJAS_SALIDA = ['Validacion', 'Integrada', 'Detalle', 'Dashboard'];
```

Funciones requeridas:
1. `obtenerSpreadsheet_()`: función resiliente que abre mediante `SpreadsheetApp.openById(id)` o `SpreadsheetApp.openByUrl(url)`. Si `ID_HOJA` no está configurado, intenta `SpreadsheetApp.getActiveSpreadsheet()`. Si falla en contexto Web App, arroja un mensaje de error claro solicitando colocar el ID/URL.
2. `onOpen()`: menú **Dashboard CNEB -> Integrar y actualizar**.
3. `leerFuentes_(ss)`: un único `getDataRange().getValues()` por hoja fuente para cuidar cuotas.
4. `extraerPeriodosOrdenados_(filasEvaluaciones)`: detección dinámica y orden natural numérico.
5. `validar_(ss, fuentes)`: escribe la hoja **Validacion** con diagnósticos frente a lo esperado, notas vacías, notas inválidas fuera de AD/A/B/C, IDs sin sección, duplicados, Asistidas > Programadas, Entregadas > Asignadas. Si hay notas inválidas, detener y alertar.
6. `integrar_(ss, fuentes, periodos)`: escribe hoja **Integrada** (alumno-periodo-curso): `Alumno_ID`, `Seccion`, `Periodo`, `Curso`, `n_AD`, `n_A`, `n_B`, `n_C`, `n_vacias`, `%Logro`, `Nivel_mediano` (letra), `%Asistencia` (global del periodo), `%Entregas` (del curso).
7. `escribirDetalle_(ss, fuentes, periodos)`: escribe hoja **Detalle** (40 filas): ID, sección, medianas dinámicas por cada periodo detectado (P1..Pn), distribución del último periodo, %asistencia, %entregas, Riesgo, Motivos, Recomendación.
8. `clasificarRiesgo_(alumnoHistorial, periodosOrdenados, asis, entr)`: clasifica con reglas de la sección 4 devolviendo nivel, motivos[] y recomendaciones[].
9. `escribirDashboard_(ss, periodos)`: hoja **Dashboard** con tablas de resumen y gráficos nativos (`EmbeddedChartBuilder`).
10. `getDatosDashboard()`: función con **auto-inicialización integrada (Lazy Processing)**. Si la hoja `Detalle` no existe o no tiene registros procesados, ejecuta `integrar_()` y `escribirDetalle_()` automáticamente antes de responder el JSON al cliente, evitando paneles vacíos.
11. `doGet(e)`: renderiza `Index.html` con `HtmlService.createHtmlOutputFromFile('Index')`.

**Reglas de escritura en Spreadsheet:**
- **No destruir ni recrear hojas**: usar `clearContents()`, `clearFormats()` y remover gráficos existentes sobre las hojas de salida para no invalidar referencias ni agotar cuotas. Crear la hoja solo si no existe.
- Escribir con un solo `setValues()` por bloque o matriz.
- Proteger con `LockService.getScriptLock()` al inicio del proceso para evitar ejecuciones concurrentes.

## 4. Reglas de Riesgo Pedagógico (Excluyentes y Secuenciales)

Se evalúa sobre el **último periodo registrado**: Sea `pC` y `pB` la proporción de notas C y B respecto a las notas disponibles del alumno en el último periodo; `asis` = Asistidas/Programadas; `entr` = Entregadas/Asignadas.

El primer nivel que se cumpla asigna la categoría de manera unívoca:

0. **Información insuficiente**: disponibles < `minDisponibles`. Motivo: evidencias insuficientes para clasificar.
1. **Alto** si se cumple cualquiera:
   - `pC >= 0.50`
   - `pC >= 0.34` y (`asis < 0.80` o `entr < 0.60`)
   - **Descenso sostenido**: evaluar SOLO si hay al menos 3 periodos (`periodos.length >= 3`). Cumple si el nivel mediano baja en los 2 últimos tramos consecutivos (ej. A->B->C) o si `pC` subió en cada uno de los 3 últimos periodos.
2. **Medio** si se cumple cualquiera:
   - `pC > 0`
   - `pB >= 0.50`
   - `asis < 0.90`
   - `entr < 0.80`
   - El nivel mediano bajó respecto al periodo inmediatamente anterior (evaluar si `periodos.length >= 2`).
3. **Bajo**: Resto de casos (sin C, mayoría A/AD, asistencia y entregas regulares).

Recomendaciones contextuales por motivo detectado:
- Criterios en C: plan de retroalimentación descriptiva y nueva evidencia en el siguiente periodo.
- Asistencia baja: coordinación con tutoría, bienestar y familia.
- Entregas bajas: andamiaje pedagógico, ajuste de carga y cronograma de recuperación.
- Descenso sostenido: entrevista individual formativa y ajuste metodológico.
- Bajo / AD: retos de profundización y monitoría entre pares.

## 5. Index.html (Web App Privada y Resiliente)

Interfaz responsiva con HTML5, Tailwind CSS y Chart.js desde CDN:
- **Gestión de Estados de Red**: Contenedor visual de error en el DOM (`#errorBanner`) que captura fallos de `google.script.run.withFailureHandler()`, evitando pantallas congeladas en "Cargando...".
- Filtros interactivos: Sección, Curso, Periodo y Nivel de Riesgo.
- Vistas y Gráficos:
  1. **Tarjetas resumen de riesgo** (Alto, Medio, Bajo, Insuficiente).
  2. **Gráfico de barras de logro ordinal** (AD/A/B/C del grupo).
  3. **Gráfico circular de distribución de riesgo**.
  4. **Tabla de monitoreo individual**: badges por nivel, motivos específicos y recomendación pedagógica.
- Despliegue seguro: *Ejecutar como: Yo*, *Acceso: Solo yo* o *Cualquier usuario del dominio institucional*.

## 6. Lista de Verificación de Salida

- [ ] Entrega el código de `Code.gs` e `Index.html` listos para copiar y pegar.
- [ ] Soporte dual de ID o URL de hoja en `ID_HOJA` y `obtenerSpreadsheet_()`.
- [ ] `getDatosDashboard()` cuenta con auto-procesamiento en caso de hojas vacías o no generadas.
- [ ] No existen promedios aritméticos de letras en ningún cálculo.
- [ ] Ordenamiento natural numérico aplicado en periodos (`P1` a `Pn`).
- [ ] Mediana ordinal par resuelve a piso (`Math.floor`) evitando `undefined`.
- [ ] Condición de tendencia histórica protegida con verificación de longitud de periodos.
- [ ] Reutilización de hojas con `clearContents()` sin eliminaciones destructivas.
- [ ] Frontend con banner de captura de errores en lugar de `alert()` intrusivo.
